'''
Created on 2020/1/22

@author: alexytchuang
'''

import keras, keras.layers as L
from keras.models import Sequential


def create_autoencoder(encoder, decoder, img_shape):
    inp = L.Input(img_shape)
    code = encoder(inp)
    reconstruction = decoder(code)

    autoencoder = keras.models.Model(inputs=inp, outputs=reconstruction)
    autoencoder.compile('adamax', 'mse',metrics=['accuracy'])
    return autoencoder


def dae(img_shape):

    # encoder
    encoder = Sequential()
    encoder.add(L.InputLayer(img_shape))
    encoder.add(L.Conv2D(filters=32, kernel_size=(3, 3), padding='same', activation='relu'))
    encoder.add(L.MaxPooling2D(pool_size=(2, 2)))
    encoder.add(L.Conv2D(filters=64, kernel_size=(3, 3), padding='same', activation='relu'))
    encoder.add(L.MaxPooling2D(pool_size=(2, 2)))
    encoder.add(L.Conv2D(filters=128, kernel_size=(3, 3), padding='same', activation='relu'))
    encoder.add(L.MaxPooling2D(pool_size=(2, 2)))
    encoder.add(L.Conv2D(filters=256, kernel_size=(3, 3), padding='same', activation='relu'))
    encoder.add(L.MaxPooling2D(pool_size=(2, 2)))
    encoder.add(L.Conv2D(filters=512, kernel_size=(3, 3), padding='same', activation='relu'))  # 5 layer
    encoder.add(L.MaxPooling2D(pool_size=(2, 2)))

    # decoder
    decoder = Sequential()
    decoder.add(L.InputLayer((8, 8, 512)))
    decoder.add(L.Conv2DTranspose(filters=256, kernel_size=(3, 3), strides=2, activation='relu', padding='same'))
    decoder.add(L.Conv2DTranspose(filters=128, kernel_size=(3, 3), strides=2, activation='relu', padding='same'))
    decoder.add(L.Conv2DTranspose(filters=64, kernel_size=(3, 3), strides=2, activation='relu', padding='same'))
    decoder.add(L.Conv2DTranspose(filters=32, kernel_size=(3, 3), strides=2, activation='relu', padding='same'))
    decoder.add(L.Conv2DTranspose(filters=3, kernel_size=(3, 3), strides=2, activation=None, padding='same'))

    return encoder, decoder


def dae_no_pooling(img_shape):

    # encoder
    encoder = Sequential()
    encoder.add(L.InputLayer(img_shape))
    encoder.add(L.Conv2D(filters=32, kernel_size=(3, 3), padding='same', activation='relu', strides=2))
    encoder.add(L.Conv2D(filters=64, kernel_size=(3, 3), padding='same', activation='relu', strides=2))
    encoder.add(L.Conv2D(filters=128, kernel_size=(3, 3), padding='same', activation='relu', strides=2))
    encoder.add(L.Conv2D(filters=256, kernel_size=(3, 3), padding='same', activation='relu', strides=2))
    encoder.add(L.Conv2D(filters=512, kernel_size=(3, 3), padding='same', activation='relu', strides=2))  # 5 layer

    # decoder
    decoder = Sequential()
    decoder.add(L.InputLayer((9, 9, 512)))
    decoder.add(L.Conv2DTranspose(filters=256, kernel_size=(3, 3), strides=2, activation='relu', padding='same', output_padding=0))
    decoder.add(L.Conv2DTranspose(filters=128, kernel_size=(3, 3), strides=2, activation='relu', padding='same', output_padding=0))
    decoder.add(L.Conv2DTranspose(filters=64, kernel_size=(3, 3), strides=2, activation='relu', padding='same', output_padding=0))
    decoder.add(L.Conv2DTranspose(filters=32, kernel_size=(3, 3), strides=2, activation='relu', padding='same', output_padding=0))
    decoder.add(L.Conv2DTranspose(filters=3, kernel_size=(3, 3), strides=2, activation=None, padding='same', output_padding=0))
    return encoder, decoder



import numpy as np
import cv2
import pandas as pd
import os
import logging
from utils.utils import get_yolo_boxes
from networks.yolo import create_yolov3_model, dummy_loss
from utils.generator import BatchGenerator
from utils.utils import normalize, evaluate, makedirs
from keras.callbacks import EarlyStopping, ReduceLROnPlateau
from keras.optimizers import Adam
from utils.callbacks import CustomModelCheckpoint, CustomTensorBoard
from utils.multi_gpu_model import multi_gpu_model
import tensorflow as tf
from keras.models import load_model
from preprocess.yolo_preprocessing import yolo3_infer_preprocess
from utils.anchors import gen_anchors
import configparser
from utils.dataset import load_dataset_into_cache, is_dataset_check_pass
from utils.bbox import draw_boxes, draw_ground_true_boxes, BoundBox
import matplotlib
if os.environ.get('DISPLAY', '') == '':
    matplotlib.use('Agg')
import matplotlib.pyplot as plt


def _set_default(FLAGS, name, value):
    if not hasattr(FLAGS, name):
        setattr(FLAGS, name, value)


def _initial_infer_flags(FLAGS=None):
    _set_default(FLAGS, 'enable_img_preprocess', False)
    _set_default(FLAGS, 'preprocess_type', 1)
    # preprocess parameter for preprocess 1
    _set_default(FLAGS, 'resize_size', 1000)
    _set_default(FLAGS, 'crop_out_size', 100)
    _set_default(FLAGS, 'visualize_eval_result', False)
    _set_default(FLAGS, 'visualize_thresh', 0.5)

    if FLAGS.default_config_file is not None and os.path.isfile(FLAGS.default_config_file):
        config = configparser.ConfigParser()
        config.read(FLAGS.default_config_file)

        FLAGS.resize_size = config.getint(config.default_section, 'resize_size', fallback=FLAGS.resize_size)
        FLAGS.crop_out_size = config.getint(config.default_section, 'crop_out_size', fallback=FLAGS.crop_out_size)
        FLAGS.preprocess_type = config.getint(config.default_section, 'preprocess_type', fallback=FLAGS.preprocess_type)
        FLAGS.enable_img_preprocess = config.getboolean(config.default_section, 'enable_img_preprocess', fallback=FLAGS.enable_img_preprocess)


def _initial_model_flags(FLAGS=None):
    _set_default(FLAGS, 'net_h', 416)
    _set_default(FLAGS, 'net_w', 416)
    _set_default(FLAGS, 'obj_thresh', 0.1)
    _set_default(FLAGS, 'nms_thresh', 0.45)
    _set_default(FLAGS, 'min_input_size', 288)
    _set_default(FLAGS, 'max_input_size', 448)
    _set_default(FLAGS, 'anchors', '55,69, 75,234, 133,240, 136,129, 142,363, 203,290, 228,184, 285,359, 341,260')
    _set_default(FLAGS, 'regen_anchors', False)
    _set_default(FLAGS, 'anchors_from_cfg', False)

    if FLAGS.default_config_file is not None and os.path.isfile(FLAGS.default_config_file):
        config = configparser.ConfigParser()
        config.read(FLAGS.default_config_file)

        FLAGS.regen_anchors = config.getboolean(config.default_section, 'regen_anchors', fallback=FLAGS.regen_anchors)
        FLAGS.min_input_size = config.getint(config.default_section, 'min_input_size', fallback=FLAGS.min_input_size)
        FLAGS.max_input_size = config.getint(config.default_section, 'max_input_size', fallback=FLAGS.max_input_size)
        FLAGS.net_h = config.getint(config.default_section, 'image_size', fallback=FLAGS.net_h)
        FLAGS.net_w = config.getint(config.default_section, 'image_size', fallback=FLAGS.net_w)
        FLAGS.obj_thresh = config.getfloat(config.default_section, 'obj_thresh', fallback=FLAGS.obj_thresh)
        FLAGS.nms_thresh = config.getfloat(config.default_section, 'nms_thresh', fallback=FLAGS.nms_thresh)
        if 'anchors' in config['DEFAULT'].keys():
            FLAGS.anchors = config['DEFAULT']['anchors']
            FLAGS.anchors_from_cfg = True
            FLAGS.regen_anchors = False


def _initial_train_flags(FLAGS=None):
    _set_default(FLAGS, 'train_dir', "")
    if FLAGS.train_dir == '':
        raise ValueError('You must supply the train directory ')

    #FLAGS.train_cache_name = "imt_yolo3_train.pkl"
    #FLAGS.train_cache_path = os.path.join(FLAGS.train_dir, FLAGS.train_cache_name)

    FLAGS.train_times = 1
    _set_default(FLAGS, 'batch_size', 32)
    FLAGS.learning_rate = 1e-4
    _set_default(FLAGS, 'nb_epochs', 500)
    _set_default(FLAGS, 'early_stop_patience', 100)
    FLAGS.warmup_epochs = 3
    FLAGS.ignore_thresh = 0.5
    _set_default(FLAGS, 'gpus', "0,1")

    FLAGS.grid_scales = [1, 1, 1]
    FLAGS.obj_scale = 5
    FLAGS.noobj_scale = 1
    FLAGS.xywh_scale = 1
    FLAGS.class_scale = 1

    _set_default(FLAGS, 'decay_factor', 0.1)
    _set_default(FLAGS, 'decay_patience', 16)
    _set_default(FLAGS, 'random_hsv', False)

    if FLAGS.default_config_file is not None and os.path.isfile(FLAGS.default_config_file):
        config = configparser.ConfigParser()
        config.read(FLAGS.default_config_file)

        FLAGS.decay_factor = config.getfloat(config.default_section, 'decay_factor', fallback=FLAGS.decay_factor)
        FLAGS.decay_patience = config.getint(config.default_section, 'decay_patience', fallback=FLAGS.decay_patience)
        FLAGS.random_hsv = config.getboolean(config.default_section, 'random_hsv', fallback=FLAGS.random_hsv)

    FLAGS.log_dir = FLAGS.train_dir
    _set_default(FLAGS, 'pretrained_weight_path', "")
    FLAGS.saved_weights_name = "imt_yolo3.h5"
    FLAGS.saved_weights_path = os.path.join(FLAGS.train_dir, FLAGS.saved_weights_name)
    _set_default(FLAGS, 'debug', 1)  # 0: no output message, 1: output messgae per step, 2: output message per epoch


def _initial_eval_flags(FLAGS=None):
    #FLAGS.valid_cache_name = "imt_yolo3_valid.pkl"
    #FLAGS.valid_cache_path = os.path.join(FLAGS.train_dir, FLAGS.valid_cache_name)
    FLAGS.valid_times = 1
    FLAGS.saved_weights_name = "imt_yolo3.h5"
    FLAGS.saved_weights_path = os.path.join(FLAGS.train_dir, FLAGS.saved_weights_name)
    _set_default(FLAGS, 'visualize_eval_result', False)
    _set_default(FLAGS, 'visualize_thresh', 0.5)

    if FLAGS.visualize_eval_result and FLAGS.visualize_output_dir == '':
        FLAGS.visualize_output_dir = os.path.join(FLAGS.train_dir, 'vis_result')


def _create_callbacks(saved_weights_path, log_dir, model_to_save, early_stop_patience, decay_factor, decay_patience):
    early_stop = EarlyStopping(
        monitor='val_loss',
        min_delta=0.01,
        patience=early_stop_patience,
        mode='min',
        verbose=1
    )
    checkpoint = CustomModelCheckpoint(
        model_to_save=model_to_save,
        filepath=saved_weights_path,  # + '{epoch:02d}.h5',
        monitor='val_loss',
        verbose=1,
        save_best_only=True,
        mode='min',
        period=1
    )
    reduce_on_plateau = ReduceLROnPlateau(
        monitor='loss',
        factor=decay_factor,
        patience=decay_patience,
        verbose=1,
        mode='min',
        epsilon=0.01,
        cooldown=0,
        min_lr=0
    )
    tensorboard = CustomTensorBoard(
        log_dir=log_dir,
        histogram_freq=0,
        write_graph=True,
        write_images=False,
    )
    return [early_stop, checkpoint, reduce_on_plateau, tensorboard]


def _create_model(
    nb_class,
    anchors,
    max_box_per_image,
    max_grid, batch_size,
    warmup_batches,
    ignore_thresh,
    multi_gpu,
    pretrained_weight_path,
    lr,
    grid_scales,
    obj_scale,
    noobj_scale,
    xywh_scale,
    class_scale
):
    if multi_gpu > 1:
        with tf.device('/cpu:0'):
            template_model, infer_model = create_yolov3_model(
                nb_class            = nb_class,
                anchors             = anchors,
                max_box_per_image   = max_box_per_image,
                max_grid            = max_grid,
                batch_size          = batch_size//multi_gpu,
                warmup_batches      = warmup_batches,
                ignore_thresh       = ignore_thresh,
                grid_scales         = grid_scales,
                obj_scale           = obj_scale,
                noobj_scale         = noobj_scale,
                xywh_scale          = xywh_scale,
                class_scale         = class_scale
            )
    else:
        template_model, infer_model = create_yolov3_model(
            nb_class            = nb_class,
            anchors             = anchors,
            max_box_per_image   = max_box_per_image,
            max_grid            = max_grid,
            batch_size          = batch_size,
            warmup_batches      = warmup_batches,
            ignore_thresh       = ignore_thresh,
            grid_scales         = grid_scales,
            obj_scale           = obj_scale,
            noobj_scale         = noobj_scale,
            xywh_scale          = xywh_scale,
            class_scale         = class_scale
        )

    # load the pretrained weight if exists, otherwise load the backend weight only
    if os.path.exists(pretrained_weight_path):
        print("\nLoading pretrained weights: %s.\n" % pretrained_weight_path)
        template_model.load_weights(pretrained_weight_path, by_name=True, skip_mismatch=True)

    if multi_gpu > 1:
        train_model = multi_gpu_model(template_model, gpus=multi_gpu)
    else:
        train_model = template_model

    optimizer = Adam(lr=lr, clipnorm=0.001)
    train_model.compile(loss=dummy_loss, optimizer=optimizer)

    return train_model, infer_model


def _gen_predict_report(img_id, img_file, boxes, labels):
    # generate output
    output = pd.DataFrame()
    xmin = list()
    ymin = list()
    xmax = list()
    ymax = list()
    score = list()

    if len(boxes) > 0:
        for box in boxes:
            xmin.append(box[0])
            ymin.append(box[1])
            xmax.append(box[2])
            ymax.append(box[3])
            score.append(box[4])

        output['predict_probability'] = score
        output['predict_class'] = labels
        output['box_xmin'] = xmin
        output['box_ymin'] = ymin
        output['box_xmax'] = xmax
        output['box_ymax'] = ymax
        output['image_file'] = img_file
        output['image_seq'] = img_id

        # Process zero score boxes
        # Set box coordinator to 0 and score to -9999
        # Keep only one record when all boxes score is zero
        #output.ix[(output['predict_probability'] == 0), 'box_xmin'] = 0.0
        #output.ix[(output['predict_probability'] == 0), 'box_ymin'] = 0.0
        #output.ix[(output['predict_probability'] == 0), 'box_xmax'] = 0.0
        #output.ix[(output['predict_probability'] == 0), 'box_ymax'] = 0.0
        #output.ix[(output['predict_probability'] == 0), 'predict_probability'] = -9999
        #output.drop_duplicates(inplace=True)

        # Get boxes which score > zero
        output = output[output['predict_probability'] > 0]
    
    if len(boxes) == 0 or len(output) == 0:
        output['predict_probability'] = [-1]
        output['predict_class'] = [0]
        output['box_xmin'] = [0.0]
        output['box_ymin'] = [0.0]
        output['box_xmax'] = [0.0]
        output['box_ymax'] = [0.0]
        output['image_file'] = [img_file]
        output['image_seq'] = [img_id]

    return output


def _save_anchors_to_config(anchors, config_path):
    with tf.gfile.Open(config_path, 'a+') as f:
        f.write('anchors=%s\n' % anchors)


def _convert_annotation_to_bbox(annotations):
    boxes = []
    for obj in annotations:
        box = BoundBox(obj[0], obj[1], obj[2], obj[3])
        boxes.append(box)

    return boxes


def _predict_once(FLAGS, model, raw_image, img_id, image_path, labels=None, ground_true_boxes=None):
    # convert anchors string to array
    if type(FLAGS.anchors) is str:
        FLAGS.anchors = list(map(int, FLAGS.anchors.replace(' ', '').split(',')))

    # make the boxes and the labels
    pred_boxes = \
    get_yolo_boxes(model, raw_image, FLAGS.net_h, FLAGS.net_w, FLAGS.anchors, FLAGS.obj_thresh, FLAGS.nms_thresh)[0]

    if FLAGS.visualize_eval_result:
        # draw bounding boxes on the image using labels
        tmp_img = draw_boxes(raw_image[0], pred_boxes, labels, FLAGS.visualize_thresh)

        # draw ground true boxes on the image using labels
        tmp_img = draw_ground_true_boxes(tmp_img, ground_true_boxes)

        # write the image with bounding boxes to file
        cv2.imwrite(os.path.join(FLAGS.visualize_output_dir, image_path.split('/')[-1]), np.uint8(tmp_img))

    score = np.array([box.get_score() for box in pred_boxes])
    pred_labels = np.array([box.label for box in pred_boxes])

    if len(pred_boxes) > 0:
        pred_boxes = np.array([[box.xmin, box.ymin, box.xmax, box.ymax, box.get_score()] for box in pred_boxes])
    else:
        pred_boxes = np.array([[]])

    # sort the boxes and the labels according to scores
    score_sort = np.argsort(-score)
    pred_labels = pred_labels[score_sort]
    pred_boxes = pred_boxes[score_sort]

    image_file = os.path.basename(image_path)
    pred_result = _gen_predict_report(img_id, image_file, pred_boxes, pred_labels)

    return pred_result


def _plot_loss(index_list, train_loss_list, valid_loss_list, x_step, y_loss):
    font = {'family': 'serif',
            'color': 'darkred',
            'weight': 'normal',
            'size': 12,
            }

    # matplotlib.use('Gtk3Agg')
    matplotlib.use('Agg')
    fig, ax = plt.subplots()
    #circle = plt.Circle((x_step, y_loss), 0.1, color='b', fill=False)
    #ax.add_artist(circle)

    plt.plot(index_list, train_loss_list, linewidth=2, label='train loss')
    plt.plot(index_list, valid_loss_list, linewidth=2, label='valid loss')
    ax.set_xlim(left=0)
    ax.set_ylim(bottom=0)
    y_top = int(y_loss) + 20
    if max(train_loss_list + valid_loss_list) > y_top:
        ax.set_ylim(top=y_top)

    ax.plot(x_step, y_loss, color='darkred', marker='*', markersize=12)
    plt.grid()
    plt.xlabel('epochs')
    plt.ylabel('loss')
    plt.title(r'$Best Epoch: %d ,Best Loss: %f$' % (x_step, y_loss), fontdict=font)
    plt.legend(loc='best')
    return plt


def _check_net_setting(max_input_size, image_size):
    if image_size > max_input_size:
        raise ValueError('image_size must be smaller or equal to max_input_size')


def do_train(FLAGS, do_initialize, train_dataset_path, valid_dataset_path, labels):
    """
    :param FLAGS: Training parameters.
    :param do_initialize: Initializing default parameters or not.
    :param train_dataset_path: Training dataset path.
    :param valid_dataset_path: Validation dataset path.
    :param labels: A list of all class names for training and validation.
    :return:
    """
    if do_initialize:
        _initial_model_flags(FLAGS)
        _initial_train_flags(FLAGS)
        _initial_eval_flags(FLAGS)

    _check_net_setting(FLAGS.max_input_size, FLAGS.net_h)

    if not tf.gfile.Exists(FLAGS.train_dir):
        tf.gfile.MakeDirs(FLAGS.train_dir)

    # load training set from dataset
    if os.path.exists(train_dataset_path):
        train_ints, train_labels = load_dataset_into_cache(train_dataset_path)
    else:
        raise ValueError('Can not load training dataset!')

    # load validation set from dataset
    if os.path.exists(valid_dataset_path):
        valid_ints, valid_labels = load_dataset_into_cache(valid_dataset_path)
    else:
        raise ValueError('Can not load validation dataset!')

    #if not is_dataset_check_pass(train_labels, valid_labels, labels):
    #    raise ValueError('There are some problems of dataset! Skip training.')

    max_box_per_image = max([len(inst['object']) for inst in (train_ints + valid_ints)])

    ##############################
    #   Generate anchors
    ##############################
    if FLAGS.regen_anchors:
        if FLAGS.anchors_from_cfg is False:
            anchors_str = gen_anchors(train_ints)
            _save_anchors_to_config(anchors_str, FLAGS.default_config_file)

            # convert anchors string to array
            FLAGS.anchors = list(map(int, anchors_str.replace(' ', '').split(',')))
        else:
            FLAGS.anchors = list(map(int, FLAGS.anchors.replace(' ', '').split(',')))
    else:
        if FLAGS.anchors_from_cfg is False:
            _save_anchors_to_config(FLAGS.anchors, FLAGS.default_config_file)
        FLAGS.anchors = list(map(int, FLAGS.anchors.replace(' ', '').split(',')))

    ###############################
    #   Create the generators
    ###############################
    train_generator = BatchGenerator(
        instances=train_ints,
        anchors=FLAGS.anchors,
        labels=labels,
        downsample=32,  # ratio between network input's size and network output's size, 32 for YOLOv3
        max_box_per_image=max_box_per_image,
        batch_size=FLAGS.batch_size,
        min_net_size=FLAGS.min_input_size,
        max_net_size=FLAGS.max_input_size,
        shuffle=True,
        jitter=0.3,
        norm=normalize,
        random_hsv=FLAGS.random_hsv
    )

    valid_generator = BatchGenerator(
        instances=valid_ints,
        anchors=FLAGS.anchors,
        labels=labels,
        downsample=32,  # ratio between network input's size and network output's size, 32 for YOLOv3
        max_box_per_image=max_box_per_image,
        batch_size=FLAGS.batch_size,
        min_net_size=FLAGS.min_input_size,
        max_net_size=FLAGS.max_input_size,
        shuffle=True,
        jitter=0.0,
        norm=normalize,
        random_hsv=False
    )

    ###############################
    #   Create the model
    ###############################
    if os.path.exists(FLAGS.saved_weights_path):
        FLAGS.warmup_epochs = 0
    warmup_batches = FLAGS.warmup_epochs * FLAGS.train_times * len(train_generator)

    os.environ['CUDA_VISIBLE_DEVICES'] = FLAGS.gpus
    multi_gpu = len(FLAGS.gpus.split(','))

    train_model, infer_model = _create_model(
        nb_class=len(labels),
        anchors=FLAGS.anchors,
        max_box_per_image=max_box_per_image,
        max_grid=[FLAGS.max_input_size, FLAGS.max_input_size],
        batch_size=FLAGS.batch_size,
        warmup_batches=warmup_batches,
        ignore_thresh=FLAGS.ignore_thresh,
        multi_gpu=multi_gpu,
        pretrained_weight_path=FLAGS.pretrained_weight_path,
        lr=FLAGS.learning_rate,
        grid_scales=FLAGS.grid_scales,
        obj_scale=FLAGS.obj_scale,
        noobj_scale=FLAGS.noobj_scale,
        xywh_scale=FLAGS.xywh_scale,
        class_scale=FLAGS.class_scale,
    )

    ###############################
    #   Kick off the training
    ###############################
    callbacks = _create_callbacks(FLAGS.saved_weights_path, FLAGS.log_dir,
                                  infer_model, FLAGS.early_stop_patience,
                                  FLAGS.decay_factor, FLAGS.decay_patience)

    hist = train_model.fit_generator(
        generator=train_generator,
        validation_data=valid_generator,
        steps_per_epoch=len(train_generator) * FLAGS.train_times,
        epochs=FLAGS.nb_epochs + FLAGS.warmup_epochs,
        verbose=FLAGS.debug,
        callbacks=callbacks,
        workers=4,
        max_queue_size=8
    )

    ## Plot training and validation trend chart
    train_loss = hist.history['loss']
    val_loss = hist.history['val_loss']
    train_steps = range(1, len(train_loss)+1)
    best_loss = min(val_loss)
    best_step = val_loss.index(min(val_loss))+1

    _plot_loss(train_steps, train_loss, val_loss, best_step, best_loss)
    plt.savefig('%s/loss_trend.jpg' % FLAGS.train_dir)

    ## make a GPU version of infer_model for evaluation
    #if multi_gpu > 1:
    #    infer_model = load_model(FLAGS.saved_weights_path)
    #
    ################################
    ##   Run the evaluation
    ################################
    ## compute mAP for all the classes
    #average_precisions = evaluate(infer_model, valid_generator)
    #
    ## print the score
    #for label, average_precision in average_precisions.items():
    #    print(labels[label] + ': {:.4f}'.format(average_precision))
    #print('mAP: {:.4f}'.format(sum(average_precisions.values()) / len(average_precisions)))


def do_eval(FLAGS, do_initialize, model, output_path, valid_dataset_path, labels):
    """
    :param FLAGS: Validation parameters.
    :param do_initialize: Initializing default parameters or not.
    :param model: Model instance.
    :param output_path: Prediction result output path.
    :param valid_dataset_path: Validation dataset path.
    :param labels: A list of all class names for training and validation.
    :return:
    """
    if do_initialize:
        _initial_model_flags(FLAGS)
        _initial_eval_flags(FLAGS)

    _check_net_setting(FLAGS.max_input_size, FLAGS.net_h)
    ###############################
    #   Create the validation generator
    ###############################
    # load validation set from dataset
    if os.path.exists(valid_dataset_path):
        valid_ints, valid_labels = load_dataset_into_cache(valid_dataset_path)
    else:
        raise ValueError('Can not load validation dataset!')

    valid_generator = BatchGenerator(
        instances=valid_ints,
        anchors=FLAGS.anchors,
        labels=labels,
        downsample=32,  # ratio between network input's size and network output's size, 32 for YOLOv3
        max_box_per_image=0,
        batch_size=1,
        min_net_size=FLAGS.min_input_size,
        max_net_size=FLAGS.max_input_size,
        shuffle=False,
        jitter=0.0,
        norm=normalize,
        random_hsv=False
    )

    ###############################
    #   Load the model and do evaluation
    ###############################
    #infer_model = load_model(FLAGS.saved_weights_path)
    infer_model = model

    output_result = pd.DataFrame()
    if FLAGS.visualize_eval_result:
        if not tf.gfile.Exists(FLAGS.visualize_output_dir):
            tf.gfile.MakeDirs(FLAGS.visualize_output_dir)

    for i in range(valid_generator.size()):
        raw_image = [valid_generator.load_image(i)]
        img_id = valid_generator.get_image_id(i)
        if FLAGS.visualize_eval_result:
            ground_true_boxes = _convert_annotation_to_bbox(valid_generator.load_annotation(i))
            pred_result = _predict_once(FLAGS, infer_model, raw_image, img_id, valid_generator.get_image_path(i), labels, ground_true_boxes)
        else:
            pred_result = _predict_once(FLAGS, infer_model, raw_image, img_id, valid_generator.get_image_path(i))

        output_result = pd.concat([output_result, pred_result])

    output_result.to_csv(output_path, index=False)


def do_inference(FLAGS, do_initialize, model, dic_image_path, output_path, logger=None):
    """
    :param FLAGS: Inference parameters.
    :param do_initialize: Initializing default parameters or not.
    :param model: Model instance.
    :param dic_image_path: A dictionary contain image path and image id.
    :param output_path: Prediction result output path.
    :return:
    """
    if do_initialize:
        _initial_model_flags(FLAGS)
        _initial_infer_flags(FLAGS)

    _check_net_setting(FLAGS.max_input_size, FLAGS.net_h)
    output_result = pd.DataFrame()

    for img_id in dic_image_path.keys():
        try:
            image_path = dic_image_path[img_id]
            # preprocess the image
            image = cv2.imread(image_path)
            if FLAGS.enable_img_preprocess:
                resized_image = yolo3_infer_preprocess(FLAGS, image)
                raw_image = [resized_image]
            else:
                raw_image = [image]

            pred_result = _predict_once(FLAGS, model, raw_image, img_id, image_path)
            output_result = pd.concat([output_result, pred_result])
        except Exception as ex:
            if logger != None:
                logger.error(ex)

    output_result.to_csv(output_path, index=False)



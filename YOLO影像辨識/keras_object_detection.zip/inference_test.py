
import tensorflow as tf
import os
import AUO_yolo_v3
import glob
from keras.models import load_model
import argparse

flags = tf.app.flags
flags.DEFINE_string('weight_file_path', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2/20190402_T43Q4_CV100_rotation_false_no.h5',
                    'File path of model weights to evaluate')

flags.DEFINE_string('image_dir', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2/image',
                    'Image directory to inference')

flags.DEFINE_string('output_path', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2/eval_result_preprocess_default.csv',
                    'File path for save output result.')

flags.DEFINE_integer('net_h', 416,
                     'Height of network size.')

flags.DEFINE_integer('net_w', 416,
                     'Width of network size.')

flags.DEFINE_float('obj_thresh', 0.1,
                   'Threshold for object detection.')

flags.DEFINE_float('nms_thresh', 0.45,
                   'Threshold for bounding box selection.')

flags.DEFINE_string('anchors', '',
                    'Model anchors of trained model weight.')

flags.DEFINE_string('gpus', '0',
                    'Which GPU to run.')

flags.DEFINE_bool('enable_img_preprocess', True,
                  'Whether or not to enable image preprocessing for inference.')

flags.DEFINE_integer('preprocess_type', 1,
                     'Width of network size.')

flags.DEFINE_integer('resize_size', 1000,
                     'Width of network size.')

flags.DEFINE_integer('crop_out_size', 100,
                     'Width of network size.')

flags.DEFINE_boolean('default_flag', True,
                     'Turn on do_initialize or not.')

flags.DEFINE_string('default_config_file', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2/hyper_param.ini',
                    'config file to overwrite other parameters.')


FLAGS = flags.FLAGS


def main(_):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = FLAGS.gpus

    my_flag = FLAGS
    if FLAGS.default_flag:
        my_flag = argparse.ArgumentParser().parse_args('')
        my_flag.net_h = FLAGS.net_h
        my_flag.net_w = FLAGS.net_w
        my_flag.obj_thresh = FLAGS.obj_thresh
        my_flag.nms_thresh = FLAGS.nms_thresh
        my_flag.anchors = FLAGS.anchors
        my_flag.enable_img_preprocess = FLAGS.enable_img_preprocess
        my_flag.preprocess_type = FLAGS.preprocess_type
        my_flag.resize_size = FLAGS.resize_size
        my_flag.crop_out_size = FLAGS.crop_out_size
        my_flag.default_config_file = FLAGS.default_config_file

    infer_model = load_model(FLAGS.weight_file_path)

    images_path = glob.glob(FLAGS.image_dir + '/*.jpg')
    dic_images = {}
    for i in range(len(images_path)):
        image_id = 'img_' + str(i).zfill(3)
        dic_images[image_id] = images_path[i]

    AUO_yolo_v3.do_inference(my_flag, FLAGS.default_flag, infer_model, dic_images, FLAGS.output_path)


if __name__ == '__main__':
  tf.app.run()

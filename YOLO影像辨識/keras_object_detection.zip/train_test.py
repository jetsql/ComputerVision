
import tensorflow as tf
import os
import AUO_yolo_v3
import argparse
from utils.dataset import create_training_instances


flags = tf.app.flags
flags.DEFINE_string('train_dir', '/home/nfs/alexytchuang/model_output/keras_yolov3/L5C_ESH/20190418_IMT_Train_Test',
                    'Directory to save training output.')

flags.DEFINE_string('pretrained_weight_path', '/home/nfs/alexytchuang/model_output/keras_yolov3/L5C_ESH/20190418_IMT_Train_Test/imt_yolo3.h5',
                    'File path of model pre-training weight.')

flags.DEFINE_string('train_image_folder', '/home/nfs/alexytchuang/image/L5C/Object_Detection/L5C_Cell_ESH/20190418/train_image/',
                    'Image directory to training')

flags.DEFINE_string('train_annot_folder', '/home/nfs/alexytchuang/image/L5C/Object_Detection/L5C_Cell_ESH/20190418/train_xml/',
                    'Annotation directory to training')

flags.DEFINE_string('valid_image_folder', '',
                    'Image directory to validation. If empty, will select image from training image.')

flags.DEFINE_string('valid_annot_folder', '',
                    'Annotation directory to validation')

flags.DEFINE_string('output_path', '/home/nfs/alexytchuang/model_output/keras_yolov3/L5C_ESH/20190418_IMT_Train_Test/eval_result.csv',
                    'File path for save output result.')

flags.DEFINE_integer('net_h', 416,
                     'Height of image size.')

flags.DEFINE_integer('net_w', 416,
                     'Width of image size.')

flags.DEFINE_integer('batch_size', 32,
                     'How many images of a mini batch.')

flags.DEFINE_integer('nb_epochs', 10,
                     'Max epochs to train.')

flags.DEFINE_integer('early_stop_patience', 2,
                     'Epoch number of early stop patience.')

flags.DEFINE_float('obj_thresh', 0.1,
                   'Threshold for object detection.')

flags.DEFINE_float('nms_thresh', 0.45,
                   'Threshold for bounding box selection.')

flags.DEFINE_string('labels', 'person_fall, person_shoes_ng, person_shoes_ok, person_without_helmet',
                    'Model labels for training.')

flags.DEFINE_string('gpus', '0',
                    'Which GPU to run.')

flags.DEFINE_boolean('default_flag', True,
                     'Turn on do_initialize or not.')

flags.DEFINE_string('default_config_file', '/home/nfs/alexytchuang/IMT/cfg/L5C_CELL_ESH_yolo3.ini',
                    'config file to overwrite other parameters.')

flags.DEFINE_boolean('visualize_eval_result', False,
                     'Turn on visualize result or not.')

flags.DEFINE_string('visualize_output_dir', '',
                    'config file to overwrite other parameters.')

flags.DEFINE_float('visualize_thresh', 0.5,
                   'Threshold for draw bounding box.')

flags.DEFINE_integer('debug', 2,
                     'Which level for output debug messages.')

flags.DEFINE_float('decay_factor', 0.1,
                   'Learning rate decay factor.')

flags.DEFINE_integer('decay_patience', 2,
                     'Learning rate decay patience.')

flags.DEFINE_boolean('regen_anchors', True,
                     'Re-generate anchors from training images.')
FLAGS = flags.FLAGS

def main(_):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = FLAGS.gpus

    my_flag = FLAGS
    if FLAGS.default_flag:
        my_flag = argparse.ArgumentParser().parse_args('')
        my_flag.net_h = FLAGS.net_h
        my_flag.net_w = FLAGS.net_w
        my_flag.obj_thresh = FLAGS.obj_thresh
        my_flag.nms_thresh = FLAGS.nms_thresh
        my_flag.train_dir = FLAGS.train_dir
        my_flag.labels = FLAGS.labels
        my_flag.batch_size = FLAGS.batch_size
        my_flag.gpus = FLAGS.gpus
        my_flag.nb_epochs = FLAGS.nb_epochs
        my_flag.early_stop_patience = FLAGS.early_stop_patience
        my_flag.default_config_file = FLAGS.default_config_file
        my_flag.pretrained_weight_path = FLAGS.pretrained_weight_path
        my_flag.visualize_eval_result = FLAGS.visualize_eval_result
        my_flag.visualize_output_dir = FLAGS.visualize_output_dir
        my_flag.visualize_thresh = FLAGS.visualize_thresh
        my_flag.debug = FLAGS.debug
        my_flag.decay_factor = FLAGS.decay_factor
        my_flag.decay_patience = FLAGS.decay_patience
        my_flag.regen_anchors = FLAGS.regen_anchors

    if not tf.gfile.Exists(FLAGS.train_dir):
        tf.gfile.MakeDirs(FLAGS.train_dir)

    train_dataset_path = os.path.join(FLAGS.train_dir, 'imt_train_yolo3.pkl')
    valid_dataset_path = os.path.join(FLAGS.train_dir, 'imt_valid_yolo3.pkl')
    labels = sorted(FLAGS.labels.replace(' ', '').split(','))

    if not os.path.exists(train_dataset_path) or not os.path.exists(valid_dataset_path):
        create_inst_success = \
            create_training_instances(FLAGS.train_annot_folder,
                                      FLAGS.train_image_folder,
                                      train_dataset_path,
                                      FLAGS.valid_annot_folder,
                                      FLAGS.valid_image_folder,
                                      valid_dataset_path,
                                      labels)

        if not create_inst_success:
            raise ValueError('Create training and valid dataset failed!')

    AUO_yolo_v3.do_train(my_flag, FLAGS.default_flag,train_dataset_path, valid_dataset_path, labels)

    AUO_yolo_v3.do_eval(my_flag, FLAGS.default_flag, FLAGS.output_path, valid_dataset_path, labels)


if __name__ == '__main__':
    tf.app.run()

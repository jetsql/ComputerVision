from keras.callbacks import TensorBoard, ModelCheckpoint
import tensorflow as tf
import numpy as np
import warnings
from collections import defaultdict
from keras.models import save_model
import keras
#from .tqdm_utils import tqdm_notebook_failsafe


class CustomTensorBoard(TensorBoard):
    """ to log the loss after each batch
    """    
    def __init__(self, log_every=1, **kwargs):
        super(CustomTensorBoard, self).__init__(**kwargs)
        self.log_every = log_every
        self.counter = 0
    
    def on_batch_end(self, batch, logs=None):
        self.counter+=1
        if self.counter%self.log_every==0:
            for name, value in logs.items():
                if name in ['batch', 'size']:
                    continue
                summary = tf.Summary()
                summary_value = summary.value.add()
                summary_value.simple_value = value.item()
                summary_value.tag = name
                self.writer.add_summary(summary, self.counter)
            self.writer.flush()
        
        super(CustomTensorBoard, self).on_batch_end(batch, logs)

class CustomModelCheckpoint(ModelCheckpoint):
    """ to save the template model, not the multi-GPU model
    """
    def __init__(self, model_to_save, **kwargs):
        super(CustomModelCheckpoint, self).__init__(**kwargs)
        self.model_to_save = model_to_save

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.epochs_since_last_save += 1
        if self.epochs_since_last_save >= self.period:
            self.epochs_since_last_save = 0
            filepath = self.filepath.format(epoch=epoch + 1, **logs)
            if self.save_best_only:
                current = logs.get(self.monitor)
                if current is None:
                    warnings.warn('Can save best model only with %s available, '
                                  'skipping.' % (self.monitor), RuntimeWarning)
                else:
                    if self.monitor_op(current, self.best):
                        if self.verbose > 0:
                            print('\nEpoch %05d: %s improved from %0.5f to %0.5f,'
                                  ' saving model to %s'
                                  % (epoch + 1, self.monitor, self.best,
                                     current, filepath))
                        self.best = current
                        if self.save_weights_only:
                            self.model_to_save.save_weights(filepath, overwrite=True)
                        else:
                            self.model_to_save.save(filepath, overwrite=True)
                    else:
                        if self.verbose > 0:
                            print('\nEpoch %05d: %s did not improve from %0.5f' %
                                  (epoch + 1, self.monitor, self.best))
            else:
                if self.verbose > 0:
                    print('\nEpoch %05d: saving model to %s' % (epoch + 1, filepath))
                if self.save_weights_only:
                    self.model_to_save.save_weights(filepath, overwrite=True)
                else:
                    self.model_to_save.save(filepath, overwrite=True)

        super(CustomModelCheckpoint, self).on_batch_end(epoch, logs)

#class TqdmProgressCallback(keras.callbacks.Callback):
#
#    def on_train_begin(self, logs=None):
#        self.epochs = self.params['epochs']
#
#    def on_epoch_begin(self, epoch, logs=None):
#        print('\nEpoch %d/%d' % (epoch + 1, self.epochs))
#        if "steps" in self.params:
#            self.use_steps = True
#            self.target = self.params['steps']
#        else:
#            self.use_steps = False
#            self.target = self.params['samples']
#        self.prog_bar = tqdm_notebook_failsafe(total=self.target)
#        self.log_values_by_metric = defaultdict(list)
#
#    def _set_prog_bar_desc(self, logs):
#        for k in self.params['metrics']:
#            if k in logs:
#                self.log_values_by_metric[k].append(logs[k])
#        desc = "; ".join("{0}: {1:.4f}".format(k, np.mean(values)) for k, values in self.log_values_by_metric.items())
#        if hasattr(self.prog_bar, "set_description_str"):  # for new tqdm versions
#            self.prog_bar.set_description_str(desc)
#        else:
#            self.prog_bar.set_description(desc)
#
#    def on_batch_end(self, batch, logs=None):
#        logs = logs or {}
#        if self.use_steps:
#            self.prog_bar.update(1)
#        else:
#            batch_size = logs.get('size', 0)
#            self.prog_bar.update(batch_size)
#        self._set_prog_bar_desc(logs)
#
#    def on_epoch_end(self, epoch, logs=None):
#        logs = logs or {}
#        self._set_prog_bar_desc(logs)
#        self.prog_bar.update(1)  # workaround to show description
#        self.prog_bar.close()


class ModelSaveCallback(keras.callbacks.Callback):

    def __init__(self, file_name):
        super(ModelSaveCallback, self).__init__()
        self.file_name = file_name

    def on_epoch_end(self, epoch, logs=None):
        model_filename = self.file_name.format(epoch)
        save_model(self.model, model_filename)
        print("Model saved in {}".format(model_filename))

import os
import pickle
from .voc import parse_voc_annotation, parse_voc_annotation_and_split_dataset


def load_dataset_into_cache(dataset_path):
    if os.path.exists(dataset_path):
        with open(dataset_path, 'rb') as handle:
            cache = pickle.load(handle)
        all_insts, seen_labels = cache['all_insts'], cache['seen_labels']

        return all_insts, seen_labels
    else:
        raise ValueError('Dataset is not exist!')


def save_cache_to_dataset(all_insts, seen_labels, dataset_path):
    cache = {'all_insts': all_insts, 'seen_labels': seen_labels}
    with open(dataset_path, 'wb') as handle:
        pickle.dump(cache, handle, protocol=pickle.HIGHEST_PROTOCOL)


def create_training_instances(
    train_annot_folder,
    train_image_folder,
    train_dataset_path,
    valid_annot_folder,
    valid_image_folder,
    valid_dataset_path,
    labels
):

    if os.path.exists(valid_annot_folder):
        # parse annotations of the training set
        train_ints, train_labels = parse_voc_annotation(train_annot_folder, train_image_folder, labels)
        print("Saving the cache to training dataset.")
        save_cache_to_dataset(train_ints, train_labels, train_dataset_path)

        # parse annotations of the validation set
        valid_ints, valid_labels = parse_voc_annotation(valid_annot_folder, valid_image_folder, labels)
        print("Saving the cache to validation dataset.")
        save_cache_to_dataset(valid_ints, valid_labels, valid_dataset_path)

    else:
        #Split the training set and the validation set
        print("valid_annot_folder not exists. Spliting the trainining set.")

        train_ints, train_labels, valid_ints, valid_labels = \
            parse_voc_annotation_and_split_dataset(train_annot_folder, train_image_folder, labels)
        print("Saving the cache to training and validation dataset.")
        save_cache_to_dataset(train_ints, train_labels, train_dataset_path)
        save_cache_to_dataset(valid_ints, valid_labels, valid_dataset_path)

    # Check the dataset
    check_result = is_dataset_check_pass(train_labels, valid_labels, labels)

    return check_result


def create_testing_instances(
    test_annot_folder,
    test_image_folder,
    test_dataset_path,
    labels
):
    # parse annotations of the testing set
    test_ints, test_labels = parse_voc_annotation(test_annot_folder, test_image_folder, labels)
    print("Saving the cache to testing dataset.")
    save_cache_to_dataset(test_ints, test_labels, test_dataset_path)

    return True


def is_dataset_check_pass(train_labels, valid_labels, all_labels):
    if len(all_labels) > 0:
        train_overlap_labels = set(all_labels).intersection(set(train_labels.keys()))
        valid_overlap_labels = set(all_labels).intersection(set(valid_labels.keys()))

        # return None, None, None if some given label is not in the dataset
        if len(train_overlap_labels) < len(all_labels):
            print('Some labels have no annotations! Please revise the list of labels.')
            return False
        elif len(valid_overlap_labels) < len(all_labels):
            print('Some labels are lack of validation dataset! Please check selection method.')
            return False
        else:
            return True
    else:
        print('No labels! Please revise the list of labels.')
        return False

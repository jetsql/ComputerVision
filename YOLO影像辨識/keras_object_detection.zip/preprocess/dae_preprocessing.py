'''
Created on 2020/1/22

@author: alexytchuang
'''

import cv2
import numpy as np

# gray
def hist_match1(source, template):
    assert source.ndim == 2
    assert template.ndim == 2

    hist1, _ = np.histogram(source, 256, [0, 256])
    cdf1 = hist1.cumsum()
    cdf1 = cdf1 / cdf1[-1]

    hist2, bins2 = np.histogram(template, 256, [0, 256])
    cdf2 = hist2.cumsum()
    cdf2 = cdf2 / cdf2[-1]

    t = np.interp(cdf1, cdf2, bins2[:-1])
    return np.uint8(t[source])


# rgb
def hist_match3(source, template):
    assert source.ndim == 3
    assert template.ndim == 3
    assert source.shape[2] == template.shape[2]

    dst = np.zeros_like(source)
    for i in range(source.shape[2]):
        dst[:, :, i] = hist_match1(source[:, :, i], template[:, :, i])

    return dst


def cvt_hist(image_file, template_file):
    im = image_file
    template = cv2.imread(template_file)
    dst = hist_match3(im, template)
    return dst


def apply_gaussian_noise(X, sigma=0.1):
    """
    adds noise from standard normal distribution with standard deviation sigma
    :param X: image tensor of shape [batch,height,width,3]
    Returns X + noise.
    """
    noise = np.random.normal(0, sigma, X.shape)
    return X + noise


def partial_gaussian_noise(X, sigma=0.1):
    X = np.array(X, dtype=np.float)
    M = X!=0
    noise = np.random.normal(0, sigma, X.shape)
    X[M] += noise[M]
    return X

import cv2
import numpy as np


def image_resize_and_central_crop(image, resize_size, crop_out_size):
    img = cv2.resize(image, (resize_size, resize_size))
    img_np = np.array(img)
    img_np = img_np[crop_out_size:img.shape[0] - 2 * crop_out_size, crop_out_size:img.shape[1] - crop_out_size]
    img = cv2.resize(img_np, (resize_size, resize_size))

    return img


def yolo3_infer_preprocess(FLAGS, image):
    if FLAGS.preprocess_type == 1:
        rtn_img = image_resize_and_central_crop(image, FLAGS.resize_size, FLAGS.crop_out_size)

    return rtn_img


import tensorflow as tf
import os
import AUO_yolo_v3
import argparse
from utils.dataset import create_testing_instances


flags = tf.app.flags
flags.DEFINE_string('train_dir', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2',
                    'Directory to save training output.')

flags.DEFINE_string('valid_image_folder', '',
                    'Image directory to validation. If empty, will select image from training image.')

flags.DEFINE_string('valid_annot_folder', '',
                    'Annotation directory to validation')

flags.DEFINE_string('output_path', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2/eval_result.csv',
                    'File path for save output result.')

flags.DEFINE_integer('net_h', 480,
                     'Height of image size.')

flags.DEFINE_integer('net_w', 480,
                     'Width of image size.')

flags.DEFINE_integer('batch_size', 32,
                     'How many images of a mini batch.')

flags.DEFINE_float('obj_thresh', 0.1,
                   'Threshold for object detection.')

flags.DEFINE_float('nms_thresh', 0.3,
                   'Threshold for bounding box selection.')

flags.DEFINE_string('labels', 'E-1-R,I-Dt,I-Dt-Sd,On-F_D,P-1-O,P-1-R,T-1-P,T-1-R,T-1-W',
                    'Model labels for training.')

flags.DEFINE_string('gpus', '0',
                    'Which GPU to run.')

flags.DEFINE_boolean('default_flag', True,
                     'Turn on do_initialize or not.')

flags.DEFINE_string('default_config_file', '/home/nfs/alexytchuang/image/IMT_Test/20190502_v1.2.2/hyper_param.ini',
                    'config file to overwrite other parameters.')

flags.DEFINE_boolean('visualize_eval_result', False,
                     'Turn on visualize result or not.')

flags.DEFINE_string('visualize_output_dir', '',
                    'config file to overwrite other parameters.')

flags.DEFINE_float('visualize_thresh', 0.5,
                   'Threshold for draw bounding box.')

FLAGS = flags.FLAGS

def main(_):
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = FLAGS.gpus

    my_flag = FLAGS
    if FLAGS.default_flag:
        my_flag = argparse.ArgumentParser().parse_args('')
        my_flag.net_h = FLAGS.net_h
        my_flag.net_w = FLAGS.net_w
        my_flag.obj_thresh = FLAGS.obj_thresh
        my_flag.nms_thresh = FLAGS.nms_thresh
        my_flag.train_dir = FLAGS.train_dir
        my_flag.labels = FLAGS.labels
        my_flag.batch_size = FLAGS.batch_size
        my_flag.default_config_file = FLAGS.default_config_file
        my_flag.visualize_eval_result = FLAGS.visualize_eval_result
        my_flag.visualize_output_dir = FLAGS.visualize_output_dir
        my_flag.visualize_thresh = FLAGS.visualize_thresh

    valid_dataset_path = os.path.join(FLAGS.train_dir, 'imt_valid_yolo3.pkl')
    labels = sorted(FLAGS.labels.replace(' ', '').split(','))
    if os.path.exists(FLAGS.valid_annot_folder):
        create_inst_success = \
            create_testing_instances(FLAGS.valid_annot_folder,
                                     FLAGS.valid_image_folder,
                                     valid_dataset_path,
                                     labels)
        if not create_inst_success:
            raise ValueError('Create test dataset failed!')

    AUO_yolo_v3.do_eval(my_flag, FLAGS.default_flag, FLAGS.output_path, valid_dataset_path, labels)


if __name__ == '__main__':
    tf.app.run()
